#coding:utf-8

#configure

# 本地库的验证账户和密码
ADMIN_NAME = "cjj"
ADMIN_PASSWORD = "cjj"
PROJECT_NAME = "easybomd"