#coding:utf-8

from mysql4comment import CreateTableComment
from mysql4essay import CreateTableEssay
from sae.storage import Bucket, Connection

PROJECT_NAME = ""

CreateTableEssay()
# CreateTableComment()
# Bucket('resources').put()