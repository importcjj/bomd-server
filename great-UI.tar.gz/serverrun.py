#!/Users/cjj/remoteServer/flask/bin/python

from views import app

app.run(host="0.0.0.0", debug = True)
